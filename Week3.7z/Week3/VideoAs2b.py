import cv2

saved_cap = cv2.VideoCapture('video.avi')

while True:
    ret, frame = saved_cap.read()
    if not ret:
        break

    cv2.imshow('Saved Video', frame)

    if cv2.waitKey(25) == 27:  # Press 'Esc' key to exit
        break

saved_cap.release()
cv2.destroyAllWindows()
