import cv2
import numpy as np

class ShapeCenterFinder:
    def __init__(self):
        self.cap = cv2.VideoCapture(0)
        cv2.namedWindow("Grayscale", cv2.WINDOW_NORMAL)
        cv2.namedWindow("Blurred", cv2.WINDOW_NORMAL)
        cv2.namedWindow("Edges", cv2.WINDOW_NORMAL)

    def find_center(self, contour):
        M = cv2.moments(contour)
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
        else:
            cX, cY = 0, 0
        return cX, cY

    def process_frame(self):
        while True:
            ret, frame = self.cap.read()
            if not ret:
                break

            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            cv2.imshow("Grayscale", gray_frame)

            blurred_frame = cv2.GaussianBlur(gray_frame, (5, 5), 0)
            cv2.imshow("Blurred", blurred_frame)

            edges = cv2.Canny(blurred_frame, threshold1=30, threshold2=100)
            cv2.imshow("Edges", edges)

            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            labeled_frame = frame.copy()

            for contour in contours:
                epsilon = 0.04 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)

                if len(approx) >= 3:
                    num_vertices = len(approx)
                    area = cv2.contourArea(contour)
                    if area > 100:
                        shape_label = "Undefined"

                        if num_vertices == 3:
                            shape_label = "Triangle"
                        elif num_vertices == 4:
                            shape_label = "Square/Rect."
                        elif num_vertices > 6:
                            shape_label = "Circle"

                        cX, cY = self.find_center(contour)

                        hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
                        x, y, w, h = cv2.boundingRect(contour)
                        roi = hsv_frame[y:y+h, x:x+w]
                        avg_color = np.mean(roi, axis=(0, 1))
                        h, s, v = avg_color

                        lower_red = np.array([0, 50, 50])
                        upper_red = np.array([10, 255, 255])

                        lower_blue = np.array([90, 50, 50])
                        upper_blue = np.array([130, 255, 255])

                        if (cv2.inRange(roi, lower_red, upper_red).any()):
                            color_label = "Red"
                        elif (cv2.inRange(roi, lower_blue, upper_blue).any()):
                            color_label = "Blue"
                        else:
                            color_label = "Undefined"

                        cv2.drawContours(labeled_frame, [approx], 0, (0, 255, 0), 2)
                        cv2.putText(labeled_frame, f"{shape_label} ({cX}, {cY}) - {color_label}", (cX - 60, cY - 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2)
                        cv2.circle(labeled_frame, (cX, cY), 3, (0, 0, 0), -1)

            cv2.imshow("Labeled", labeled_frame)

            if cv2.waitKey(1) & 0xFF == 27:
                break

    def run(self):
        self.process_frame()
        self.cap.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    center_finder = ShapeCenterFinder()
    center_finder.run()
