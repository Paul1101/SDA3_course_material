import cv2
import time

cap = cv2.VideoCapture(0)
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('video.avi', fourcc, 20.0, (640, 480))

start_time = time.time()
record_duration = 5  # 5 seconds

while (time.time() - start_time) < record_duration:
    ret, frame = cap.read()
    cv2.imshow('Recording', frame)
    out.write(frame)
    if cv2.waitKey(1) == 27:  # 27 is the ASCII code for 'Esc'
        break

cap.release()
out.release()
cv2.destroyAllWindows()

saved_cap = cv2.VideoCapture('video.avi')
while True:
    ret, frame = saved_cap.read()
    if not ret:
        break
    cv2.imshow('Saved Video', frame)
    if cv2.waitKey(25) == 27:  # 27 is the ASCII code for 'Esc'
        break

saved_cap.release()
cv2.destroyAllWindows()
