from PIL import Image, ImageTk, ImageDraw
import tkinter as tk
from tkinter import messagebox

image_path = 'C:/Users/paulp/Desktop/Python/New folder/dog.jpg'

def open_image():
    img = Image.open(image_path)
    if img.width < 1800 or img.height < 1400:
        messagebox.showinfo("Error", "Photo is not at least 1800x1400")
        return

    img_tk = ImageTk.PhotoImage(img)
    panel.configure(image=img_tk)
    panel.image = img_tk
    root.after(3000, resize_image, img)

def resize_image(original_image):
    panel.destroy()
    img_resized = original_image.resize((int(original_image.width * 0.6), int(original_image.height * 0.6)))
    img_tk_resized = ImageTk.PhotoImage(img_resized)
    panel_resized = tk.Label(root, image=img_tk_resized)
    panel_resized.image = img_tk_resized
    panel_resized.pack()
    root.after(2000, convert_to_grayscale, img_resized)

def convert_to_grayscale(image):
    img_gray = image.convert("L")
    img_tk_gray = ImageTk.PhotoImage(img_gray)
    grayscale_window = tk.Toplevel(root)
    grayscale_window.title("Grayscale Image")
    panel_gray = tk.Label(grayscale_window, image=img_tk_gray)
    panel_gray.image = img_tk_gray
    panel_gray.pack()
    root.after(2000, crop_and_display, image)

def crop_and_display(image):
    img_cropped = image.crop((20, 20, 420, 420))
    img_tk_cropped = ImageTk.PhotoImage(img_cropped)
    cropped_window = tk.Toplevel(root)
    cropped_window.title("Cropped Image")
    panel_cropped = tk.Label(cropped_window, image=img_tk_cropped)
    panel_cropped.image = img_tk_cropped
    panel_cropped.pack()
    root.after(2000, draw_circle, img_cropped)

def draw_circle(image):
    draw = ImageDraw.Draw(image)
    draw.ellipse([20, 20, 40, 40], outline="yellow", width=2)
    img_tk_with_circle = ImageTk.PhotoImage(image)
    cropped_with_circle_window = tk.Toplevel(root)
    cropped_with_circle_window.title("Cropped Image with Circle")
    panel_with_circle = tk.Label(cropped_with_circle_window, image=img_tk_with_circle)
    panel_with_circle.image = img_tk_with_circle
    panel_with_circle.pack()
    root.after(2000, draw_ellipse, image)

def draw_ellipse(image):
    draw = ImageDraw.Draw(image)
    draw.ellipse([375, 20, 450, 60], fill="blue")
    img_tk_with_ellipse = ImageTk.PhotoImage(image)
    cropped_with_ellipse_window = tk.Toplevel(root)
    cropped_with_ellipse_window.title("Cropped Image with Circle and Ellipse")
    panel_with_ellipse = tk.Label(cropped_with_ellipse_window, image=img_tk_with_ellipse)
    panel_with_ellipse.image = img_tk_with_ellipse
    panel_with_ellipse.pack()
    root.after(2000, draw_square, image)

def draw_square(image):
    draw = ImageDraw.Draw(image)
    draw.rectangle([20, 375, 65, 420], outline=(192, 75, 15), width=1)
    img_tk_with_square = ImageTk.PhotoImage(image)
    cropped_with_square_window = tk.Toplevel(root)
    cropped_with_square_window.title("Cropped Image with Circle, Ellipse, and Square")
    panel_with_square = tk.Label(cropped_with_square_window, image=img_tk_with_square)
    panel_with_square.image = img_tk_with_square
    panel_with_square.pack()
    root.after(2000, complete_all_tasks, image)

def complete_all_tasks(image):
    draw = ImageDraw.Draw(image)
    draw.rectangle([375, 375, 420, 420], fill=(192, 75, 15), outline=(192, 75, 15), width=1)
    img_tk_with_filled_square = ImageTk.PhotoImage(image)
    cropped_with_filled_square_window = tk.Toplevel(root)
    cropped_with_filled_square_window.title("Cropped Image with Circle, Ellipse, Square, and Filled Square")
    panel_with_filled_square = tk.Label(cropped_with_filled_square_window, image=img_tk_with_filled_square)
    panel_with_filled_square.image = img_tk_with_filled_square
    panel_with_filled_square.pack()

root = tk.Tk()
root.title("Image Viewer")
panel = tk.Label(root)
panel.pack()
open_image()
root.mainloop()
