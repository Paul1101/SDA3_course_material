import pygame
import sys
from BallClass2 import *

def main():
    pygame.init()

    screen_width = 800
    screen_height = 600
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Random Speed Bouncing Ball")

    clock = pygame.time.Clock()

    ball = Ball(screen, 50, 50, 40, 40, "tennis_balls.png")

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        ball.move()

        screen.fill((0, 0, 0))
        ball.draw()

        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()