import pygame
import random

class Ball:
    def __init__(self, screen, x, y, width, height, image_path):
        self.screen = screen
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (width, height))
        speedsList = [-4, -3, -2, -1, 1, 2, 3, 4]
        self.speed_x = random.choice(speedsList)
        self.speed_y = random.choice(speedsList)
        
    def move(self):
        self.x += self.speed_x
        self.y += self.speed_y

        if self.x <= 0 or self.x + self.width >= self.screen.get_width():
            self.speed_x *= -1
        if self.y <= 0 or self.y + self.height >= self.screen.get_height():
            self.speed_y *= -1

    def draw(self):
        self.screen.blit(self.image, (self.x, self.y))
