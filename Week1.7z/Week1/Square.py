import pygame
import random

class Square:
    def __init__(self, window, max_width, max_height):
        self.window = window
        self.color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        self.x = random.randint(1, max_width - 100)
        self.y = random.randint(25, max_height - 100)
        self.side_length = random.randint(10, 100)
        self.shapeType = "Square"

    def clickedInside(self, x, y):
        return self.x <= x <= self.x + self.side_length and self.y <= y <= self.y + self.side_length

    def getType(self):
        return self.shapeType

    def getArea(self):
        return self.side_length ** 2

    def draw(self):
        pygame.draw.rect(self.window, self.color, (self.x, self.y, self.side_length, self.side_length))
