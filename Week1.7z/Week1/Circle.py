import pygame
import random
import math

class Circle:
    def __init__(self, window, max_width, max_height):
        self.window = window
        self.color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        self.radius = random.randint(10, 50)
        self.x = random.randint(1, max_width - 100)
        self.y = random.randint(25, max_height - 100)
        self.shapeType = "Circle"

    def clickedInside(self, x, y):
        distance = math.sqrt((self.x + self.radius - x) ** 2 + (self.y + self.radius - y) ** 2)
        return distance <= self.radius

    def getType(self):
        return self.shapeType

    def getArea(self):
        return math.pi * self.radius ** 2

    def draw(self):
        pygame.draw.circle(self.window, self.color, (self.x + self.radius, self.y + self.radius), self.radius)
    