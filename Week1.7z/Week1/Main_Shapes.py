import pygame
import random
import sys
from Circle import *
from Square import *
from Triangle import *

WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
MAX_SHAPES = 6

pygame.init()

window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Random Shapes")

BLACK = (0, 0, 0)

shapesList = []

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = pygame.mouse.get_pos()
            for shape in shapesList:
                if shape.clickedInside(x, y):
                    print(f"Clicked on a {shape.getType()} with area {shape.getArea()}")

    if len(shapesList) < MAX_SHAPES:
        shape_type = random.choice([Circle, Square, Triangle])
        new_shape = shape_type(window, WINDOW_WIDTH, WINDOW_HEIGHT)
        shapesList.append(new_shape)

    window.fill(BLACK)

    for shape in shapesList:
        shape.draw()

    pygame.display.flip()
