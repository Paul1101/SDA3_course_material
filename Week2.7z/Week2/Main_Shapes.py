import pygame
from pygame.locals import *
from ShapeClass import Shape
from CircleClass import Circle
from TriangleClass import Triangle
from SquareClass import Square

pygame.init()

window_width = 800
window_height = 600
window = pygame.display.set_mode((window_width, window_height))

circle = Circle(window, window_width, window_height)
triangle = Triangle(window, window_width, window_height)
square = Square(window, window_width, window_height)

shapes = [circle, triangle, square]

font = pygame.font.Font(None, 24)

show_popup = False
popup_message = ""
popup_start_time = 0

def show_popup_message(message):
    global show_popup, popup_message, popup_start_time
    show_popup = True
    popup_message = message
    popup_start_time = pygame.time.get_ticks()

def hide_popup_message():
    global show_popup
    current_time = pygame.time.get_ticks()
    if current_time - popup_start_time >= 3000:
        show_popup = False

running = True
while running:
    for event in pygame.event.get():
        if event.type == QUIT:
            running = False

        if event.type == MOUSEBUTTONDOWN and event.button == 1:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            for shape in shapes:
                if isinstance(shape, Circle) and shape.clickedInside(mouse_x, mouse_y):
                    area_text = f"Area: {shape.calculateArea():.2f} sq units"
                    color_text = f"Color: {shape.color}"
                    shape_text = f"Shape: {shape.getType()}"
                    message = f"{area_text}\n{color_text}\n{shape_text}"

                    show_popup_message(message)
                elif isinstance(shape, Triangle) and shape.clickedInside(mouse_x, mouse_y):
                    area_text = f"Area: {shape.calculateArea():.2f} sq units"
                    color_text = f"Color: {shape.color}"
                    shape_text = f"Shape: {shape.getType()}"
                    message = f"{area_text}\n{color_text}\n{shape_text}"

                    show_popup_message(message)
                elif isinstance(shape, Square) and shape.clickedInside(mouse_x, mouse_y):
                    area_text = f"Area: {shape.calculateArea():.2f} sq units"
                    color_text = f"Color: {shape.color}"
                    shape_text = f"Shape: {shape.getType()}"
                    message = f"{area_text}\n{color_text}\n{shape_text}"

                    show_popup_message(message)

    window.fill((255, 255, 255))

    for shape in shapes:
        shape.draw()

    if show_popup:
        popup_window = pygame.Surface((300, 100))
        popup_window.fill((255, 255, 255))
        pygame.draw.rect(popup_window, (0, 0, 0), (0, 0, 300, 100), 3)

        message_surface = font.render(popup_message, True, (0, 0, 0))
        popup_window.blit(message_surface, (20, 20))

        window.blit(popup_window, (window_width // 2 - 150, window_height // 2 - 50))

        hide_popup_message()

    pygame.display.update()

pygame.quit()
