from ShapeClass import Shape
import random
import pygame

class Square(Shape):
    def __init__(self, window, maxWidth, maxHeight):
        super().__init__(window, 'Square', maxWidth, maxHeight)
        self.side_length = random.randint(20, 100)

    def clickedInside(self, x, y):
        return self.x <= x <= self.x + self.side_length and self.y <= y <= self.y + self.side_length
    
    def calculateArea(self):
        return self.side_length ** 2

    def draw(self):
        pygame.draw.rect(self.window, self.color, (self.x, self.y, self.side_length, self.side_length))
