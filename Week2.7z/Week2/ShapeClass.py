import abc
import random


class Shape(abc.ABC):
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLUE = (0, 0, 255)

    def __init__(self, window, shapeType, maxWidth, maxHeight):
        self.window = window
        self.shapeType = shapeType
        self.maxWidth = maxWidth
        self.maxHeight = maxHeight
        self.color = random.choice([Shape.RED, Shape.GREEN, Shape.BLUE])
        self.x = random.randint(0, maxWidth)
        self.y = random.randint(0, maxHeight)

    def getType(self):
        return self.shapeType
