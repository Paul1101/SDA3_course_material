from ShapeClass import Shape
import random
import pygame

class Triangle(Shape):
    def __init__(self, window, maxWidth, maxHeight):
        super().__init__(window, 'Triangle', maxWidth, maxHeight)
        self.base = random.randint(20, 100)
        self.height = random.randint(20, 100)
        self.width = random.randint(10, 100)

    def clickedInside(self, x, y):
        if self.x <= x <= self.x + self.width and self.y <= y <= self.y + self.height:
            return True
        return False
    
    def calculateArea(self):
        return 0.5 * self.base * self.height

    def draw(self):
        pygame.draw.polygon(self.window, self.color, [(self.x, self.y + self.height),
                                                       (self.x + self.width, self.y + self.height),
                                                       (self.x + self.width / 2, self.y)])

